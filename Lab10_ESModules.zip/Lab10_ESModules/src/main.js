import { createTask, toggleTask, deleteTask, filterTasks, countTasks } from './modules/tasks.js';
import { loadTasks, saveTasks } from './modules/storage.js';
import { renderTasks, renderCounter, showError, setActiveFilter } from './modules/ui.js';

let tasks = loadTasks();
let currentFilter = 'all';
const form = document.querySelector('#task-form');
const input = document.querySelector('#task-input');

function refresh() {
  renderTasks(filterTasks(tasks, currentFilter), handleToggle, handleDelete);
  renderCounter(countTasks(tasks));
  setActiveFilter(currentFilter);
}

function commit(updated) {
  tasks = updated;
  if (!saveTasks(tasks)) showError('Не удалось сохранить изменения в браузере.');
  refresh();
}

function handleToggle(id) {
  showError();
  commit(toggleTask(tasks, id));
}

function handleDelete(id) {
  showError();
  commit(deleteTask(tasks, id));
}

form.addEventListener('submit', event => {
  event.preventDefault();
  showError();
  try {
    const task = createTask(input.value);
    commit([...tasks, task]);
    input.value = '';
    input.focus();
  } catch (error) {
    showError(error.message);
  }
});

for (const button of document.querySelectorAll('[data-filter]')) {
  button.addEventListener('click', () => {
    currentFilter = button.dataset.filter;
    refresh();
  });
}

document.querySelector('#clear-completed').addEventListener('click', () => {
  showError();
  commit(tasks.filter(task => !task.completed));
});

refresh();
