const STORAGE_KEY = 'lab10_esmodules_tasks';

export function loadTasks() {
  try {
    const data = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    if (!Array.isArray(data)) return [];
    return data.filter(item => item && typeof item.id === 'string' && typeof item.title === 'string' && typeof item.completed === 'boolean');
  } catch (error) {
    console.warn('Не удалось прочитать сохранённые задачи:', error);
    return [];
  }
}

export function saveTasks(tasks) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
    return true;
  } catch (error) {
    console.warn('Не удалось сохранить задачи:', error);
    return false;
  }
}
