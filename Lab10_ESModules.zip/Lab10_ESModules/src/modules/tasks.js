// Бизнес-логика: не обращается к DOM и localStorage.
export function validateTitle(value) {
  const title = typeof value === 'string' ? value.trim() : '';
  if (!title) throw new Error('Введите название задачи.');
  if (title.length > 120) throw new Error('Название не должно превышать 120 символов.');
  return title;
}

export function createTask(value, id = crypto.randomUUID()) {
  return { id, title: validateTitle(value), completed: false };
}

export function toggleTask(tasks, id) {
  return tasks.map(task => task.id === id ? { ...task, completed: !task.completed } : task);
}

export function deleteTask(tasks, id) {
  return tasks.filter(task => task.id !== id);
}

export function filterTasks(tasks, filter) {
  if (filter === 'active') return tasks.filter(task => !task.completed);
  if (filter === 'completed') return tasks.filter(task => task.completed);
  return tasks;
}

export function countTasks(tasks) {
  return { total: tasks.length, completed: tasks.filter(task => task.completed).length };
}
