// Только DOM: построение интерфейса и отображение ошибок.
export function renderTasks(tasks, onToggle, onDelete) {
  const list = document.querySelector('#task-list');
  list.replaceChildren();
  document.querySelector('#empty-state').hidden = tasks.length > 0;

  for (const task of tasks) {
    const item = document.createElement('li');
    item.className = `task${task.completed ? ' done' : ''}`;
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.checked = task.completed;
    checkbox.setAttribute('aria-label', `Выполнено: ${task.title}`);
    checkbox.addEventListener('change', () => onToggle(task.id));
    const text = document.createElement('span');
    text.textContent = task.title; // textContent защищает от вставки HTML.
    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'delete';
    remove.textContent = 'Удалить';
    remove.setAttribute('aria-label', `Удалить: ${task.title}`);
    remove.addEventListener('click', () => onDelete(task.id));
    item.append(checkbox, text, remove);
    list.append(item);
  }
}

export function renderCounter({ total, completed }) {
  document.querySelector('#counter').textContent = `Всего: ${total} · Выполнено: ${completed}`;
}

export function showError(message = '') {
  document.querySelector('#error').textContent = message;
}

export function setActiveFilter(filter) {
  document.querySelectorAll('[data-filter]').forEach(button => {
    button.setAttribute('aria-pressed', String(button.dataset.filter === filter));
  });
}
